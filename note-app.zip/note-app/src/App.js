import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { NotesProvider } from './context/NotesContext';
import Home from './pages/Home';
import CreateNote from './pages/CreateNote';
import EditNote from './pages/EditNote';
import NoteDetail from './pages/NoteDetail';
import styled, { createGlobalStyle } from 'styled-components';

// Aggiungi GlobalStyle per impostare il font size globale
const GlobalStyle = createGlobalStyle`
  html, body {
    font-size: 18px; // Aumentato da 16px (default)
  }
`;

const AppContainer = styled.div`
  font-family: 'Arial', sans-serif;
  background-color: #f7f7f7;
  min-height: 100vh;
  font-size: 1.1rem; // Aggiungi questa linea per aumentare ulteriormente il font
`;

const Navbar = styled.nav`
  background-color: #2c3e50;
  color: white;
  padding: 15px;
  text-align: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

const NavTitle = styled.h1`
  margin: 0;
  font-size: 32px; // Aumentato da 28px
`;

function App() {
  return (
    <NotesProvider>
      <Router>
        <GlobalStyle /> {/* Aggiungi il componente GlobalStyle */}
        <AppContainer>
          <Navbar>
            <NavTitle>Note App</NavTitle>
          </Navbar>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/create" element={<CreateNote />} />
            <Route path="/edit/:id" element={<EditNote />} />
            <Route path="/note/:id" element={<NoteDetail />} />
          </Routes>
        </AppContainer>
      </Router>
    </NotesProvider>
  );
}

export default App;