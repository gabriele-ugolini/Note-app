import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import Button from '../components/common/Button';
import { useNotes } from '../hooks/useNotes';

const Container = styled.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
`;

const Content = styled.div`
  white-space: pre-wrap;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 16px;
  margin: 16px 0;
  background-color: #f9f9f9;
`;

const CategoryTag = styled.span`
  display: inline-block;
  background-color: #e0f7fa;
  color: #006064;
  padding: 6px 12px;
  border-radius: 15px;
  font-size: 16px;
  margin-bottom: 15px;
`;

const InfoBox = styled.div`
  background-color: #f5f5f5;
  border-radius: 8px;
  padding: 12px;
  margin-bottom: 16px;
  color: #555;
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 10px;
  margin-top: 20px;
`;

const NoteDetail = () => {
  const { id } = useParams();
  const { notes, deleteNote } = useNotes();
  const navigate = useNavigate();
  
  const note = notes.find(note => note.id === id);
  
  if (!note) {
    return (
      <Container>
        <p>Nota non trovata.</p>
        <Button onClick={() => navigate('/')}>Torna alla home</Button>
      </Container>
    );
  }

  // Formatta la data in modo leggibile
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };
  
  const handleDelete = () => {
    deleteNote(id);
    navigate('/');
  };
  
  return (
    <Container>
      <h1>{note.title}</h1>
      <CategoryTag>{note.category || 'Senza categoria'}</CategoryTag>
      
      <InfoBox>
        <p><strong>Creata:</strong> {formatDate(note.createdAt)}</p>
        <p><strong>Modificata:</strong> {formatDate(note.updatedAt)}</p>
      </InfoBox>
      
      <Content>{note.content}</Content>
      
      <ButtonGroup>
        <Button onClick={() => navigate('/')}>Torna alla home</Button>
        <Button onClick={() => navigate(`/edit/${id}`)}>Modifica</Button>
        <Button onClick={handleDelete}>Elimina</Button>
      </ButtonGroup>
    </Container>
  );
};

export default NoteDetail;