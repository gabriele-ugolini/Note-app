import React from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import NoteForm from '../components/notes/NoteForm';
import { useNotes } from '../hooks/useNotes';

const Container = styled.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
`;

const CreateNote = () => {
  const { addNote } = useNotes();
  const navigate = useNavigate();
  
  const handleSubmit = (values) => {
    addNote(values);
    navigate('/');
  };
  
  return (
    <Container>
      <h1>Crea Nuova Nota</h1>
      <NoteForm onSubmit={handleSubmit} />
    </Container>
  );
};

export default CreateNote;