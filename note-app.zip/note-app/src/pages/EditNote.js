import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import NoteForm from '../components/notes/NoteForm';
import { useNotes } from '../hooks/useNotes';

const Container = styled.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
`;

const EditNote = () => {
  const { id } = useParams();
  const { notes, updateNote } = useNotes();
  const navigate = useNavigate();
  
  // Trova la nota corrente
  const currentNote = notes.find(note => note.id === id);
  
  if (!currentNote) {
    return (
      <Container>
        <p>Nota non trovata.</p>
      </Container>
    );
  }
  
  const handleSubmit = (values) => {
    updateNote({
      ...values,
      id: currentNote.id,
      createdAt: currentNote.createdAt
    });
    navigate('/');
  };
  
  return (
    <Container>
      <h1>Modifica Nota</h1>
      <NoteForm initialValues={currentNote} onSubmit={handleSubmit} />
    </Container>
  );
};

export default EditNote;