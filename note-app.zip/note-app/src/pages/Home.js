import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import NoteCard from '../components/notes/NoteCard';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import { useNotes } from '../hooks/useNotes';

const Container = styled.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
`;

const SearchInput = styled(Input)`
  max-width: 300px;
  margin-bottom: 16px;
`;

const FilterContainer = styled.div`
  margin-bottom: 20px;
`;

const CategoryFilter = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 10px;
`;

const CategoryButton = styled.button`
  padding: 5px 10px;
  border-radius: 15px;
  border: 1px solid #ddd;
  background-color: ${props => props.active ? '#4caf50' : 'white'};
  color: ${props => props.active ? 'white' : '#333'};
  cursor: pointer;
  
  &:hover {
    background-color: ${props => props.active ? '#45a049' : '#f1f1f1'};
  }
`;

const Home = () => {
  const { notes } = useNotes();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [categories, setCategories] = useState([]);
  
  // Estrai tutte le categorie uniche dalle note
  useEffect(() => {
    const uniqueCategories = [...new Set(notes.map(note => note.category))];
    setCategories(uniqueCategories);
  }, [notes]);
  
  // Filtra le note in base al termine di ricerca e alla categoria selezionata
  const filteredNotes = notes.filter(note => {
    const matchesSearch = 
      note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.content.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = 
      selectedCategory === '' || note.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  const handleCategorySelect = (category) => {
    setSelectedCategory(category === selectedCategory ? '' : category);
  };
  
  return (
    <Container>
      <Header>
        <h1>Le Mie Note</h1>
        <Button onClick={() => navigate('/create')}>Nuova Nota</Button>
      </Header>
      
      <SearchInput 
        type="text" 
        placeholder="Cerca nelle note..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      
      <FilterContainer>
        <h3>Filtra per categoria:</h3>
        <CategoryFilter>
          <CategoryButton 
            active={selectedCategory === ''} 
            onClick={() => setSelectedCategory('')}
          >
            Tutte
          </CategoryButton>
          {categories.map(category => (
            <CategoryButton 
              key={category}
              active={selectedCategory === category} 
              onClick={() => handleCategorySelect(category)}
            >
              {category}
            </CategoryButton>
          ))}
        </CategoryFilter>
      </FilterContainer>
      
      {filteredNotes.length > 0 ? (
        filteredNotes.map(note => (
          <NoteCard key={note.id} note={note} />
        ))
      ) : (
        <p>
          {searchTerm || selectedCategory 
            ? 'Nessuna nota trovata con i filtri applicati.' 
            : 'Nessuna nota trovata. Crea la tua prima nota!'}
        </p>
      )}
    </Container>
  );
};

export default Home;