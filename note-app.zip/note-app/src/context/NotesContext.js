import { createContext, useReducer, useEffect } from 'react';

// Creiamo il context
export const NotesContext = createContext();

// Definiamo il reducer per gestire le azioni sulle note
function notesReducer(state, action) {
  switch (action.type) {
    case 'INIT_NOTES':
      return action.payload;
    case 'ADD_NOTE':
      return [...state, action.payload];
    case 'UPDATE_NOTE':
      return state.map(note => 
        note.id === action.payload.id ? action.payload : note
      );
    case 'DELETE_NOTE':
      return state.filter(note => note.id !== action.payload);
    default:
      return state;
  }
}

// Provider component
export const NotesProvider = ({ children }) => {
  const [notes, dispatch] = useReducer(notesReducer, []);

  // Carica note dal localStorage all'avvio
  useEffect(() => {
    const storedNotes = localStorage.getItem('notes');
    if (storedNotes) {
      dispatch({ type: 'INIT_NOTES', payload: JSON.parse(storedNotes) });
    }
  }, []);

  // Salva note nel localStorage quando cambiano
  useEffect(() => {
    localStorage.setItem('notes', JSON.stringify(notes));
  }, [notes]);

  // Funzioni per manipolare le note
  const addNote = (note) => {
    const newNote = {
      ...note,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    dispatch({ type: 'ADD_NOTE', payload: newNote });
  };

  const updateNote = (updatedNote) => {
    const noteWithTimestamp = {
      ...updatedNote,
      updatedAt: new Date().toISOString()
    };
    dispatch({ type: 'UPDATE_NOTE', payload: noteWithTimestamp });
  };

  const deleteNote = (id) => {
    dispatch({ type: 'DELETE_NOTE', payload: id });
  };

  return (
    <NotesContext.Provider value={{ notes, addNote, updateNote, deleteNote }}>
      {children}
    </NotesContext.Provider>
  );
};