import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import Input from '../common/Input';
import TextArea from '../common/TextArea';
import Button from '../common/Button';
import { useNotes } from '../../hooks/useNotes';

const Form = styled.form`
  max-width: 600px;
  margin: 0 auto;
`;

const Select = styled.select`
  width: 100%;
  padding: 8px;
  margin: 8px 0;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 16px;
  box-sizing: border-box;
`;

const NoteForm = ({ initialValues = { title: '', content: '', category: '' }, onSubmit }) => {
  const { notes } = useNotes();
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [categories, setCategories] = useState([]);
  const [newCategory, setNewCategory] = useState('');
  const [showNewCategory, setShowNewCategory] = useState(false);
  
  // Estrai tutte le categorie uniche dalle note
  useEffect(() => {
    const uniqueCategories = [...new Set(notes.map(note => note.category).filter(Boolean))];
    setCategories(uniqueCategories);
    
    // Se la categoria iniziale non esiste già, mostra il campo per la nuova categoria
    if (initialValues.category && !uniqueCategories.includes(initialValues.category)) {
      setShowNewCategory(true);
      setNewCategory(initialValues.category);
    }
  }, [notes, initialValues.category]);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value
    });
    
    // Reset error when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };
  
  const handleCategoryChange = (e) => {
    const value = e.target.value;
    
    if (value === "nuova") {
      setShowNewCategory(true);
      setValues({
        ...values,
        category: ''
      });
    } else {
      setShowNewCategory(false);
      setValues({
        ...values,
        category: value
      });
    }
  };
  
  const handleNewCategoryChange = (e) => {
    const value = e.target.value;
    setNewCategory(value);
    setValues({
      ...values,
      category: value
    });
  };
  
  const validate = () => {
    const newErrors = {};
    if (!values.title.trim()) {
      newErrors.title = 'Il titolo è obbligatorio';
    }
    if (!values.content.trim()) {
      newErrors.content = 'Il contenuto è obbligatorio';
    }
    if (!values.category.trim()) {
      newErrors.category = 'La categoria è obbligatoria';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(values);
    }
  };
  
  return (
    <Form onSubmit={handleSubmit}>
      <div>
        <label htmlFor="title">Titolo</label>
        <Input
          id="title"
          name="title"
          type="text"
          placeholder="Titolo della nota"
          value={values.title}
          onChange={handleChange}
        />
        {errors.title && <p style={{ color: 'red' }}>{errors.title}</p>}
      </div>
      
      <div>
        <label htmlFor="category">Categoria</label>
        {categories.length > 0 && !showNewCategory ? (
          <Select
            id="category"
            name="category"
            value={values.category}
            onChange={handleCategoryChange}
          >
            <option value="">Seleziona una categoria</option>
            {categories.map(category => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
            <option value="nuova">+ Nuova categoria</option>
          </Select>
        ) : (
          <Input
            id="newCategory"
            name="newCategory"
            type="text"
            placeholder="Nuova categoria"
            value={newCategory}
            onChange={handleNewCategoryChange}
          />
        )}
        {!showNewCategory && (
          <Button type="button" onClick={() => setShowNewCategory(true)}>
            Cambia categoria
          </Button>
        )}
        {errors.category && <p style={{ color: 'red' }}>{errors.category}</p>}
      </div>
      
      <div>
        <label htmlFor="content">Contenuto</label>
        <TextArea
          id="content"
          name="content"
          placeholder="Contenuto della nota"
          value={values.content}
          onChange={handleChange}
        />
        {errors.content && <p style={{ color: 'red' }}>{errors.content}</p>}
      </div>
      
      <Button type="submit">Salva</Button>
    </Form>
  );
};

export default NoteForm;