import React from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import Button from '../common/Button';
import { useNotes } from '../../hooks/useNotes';

const Card = styled.div`
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 16px;
  margin: 16px 0;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

const Title = styled.h3`
  margin-top: 0;
`;

const Content = styled.p`
  color: #666;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
`;

const CategoryTag = styled.span`
  display: inline-block;
  background-color: #e0f7fa;
  color: #006064;
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 14px;
  margin-bottom: 8px;
`;

const InfoRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: #777;
  font-size: 14px;
  margin-top: 10px;
`;

const ButtonGroup = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-top: 10px;
`;

const NoteCard = ({ note }) => {
  const navigate = useNavigate();
  const { deleteNote } = useNotes();

  // Formatta la data in modo leggibile
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  return (
    <Card>
      <CategoryTag>{note.category || 'Senza categoria'}</CategoryTag>
      <Title>{note.title}</Title>
      <Content>{note.content}</Content>
      <InfoRow>
        <div>Creata: {formatDate(note.createdAt)}</div>
        <div>Modificata: {formatDate(note.updatedAt)}</div>
      </InfoRow>
      <ButtonGroup>
        <Button onClick={() => navigate(`/note/${note.id}`)}>Visualizza</Button>
        <Button onClick={() => navigate(`/edit/${note.id}`)}>Modifica</Button>
        <Button onClick={() => deleteNote(note.id)}>Elimina</Button>
      </ButtonGroup>
    </Card>
  );
};

export default NoteCard;