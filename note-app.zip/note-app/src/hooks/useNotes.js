import { useContext } from 'react';
import { NotesContext } from '../context/NotesContext';

export const useNotes = () => {
  const context = useContext(NotesContext);
  if (!context) {
    throw new Error('useNotes deve essere usato all\'interno di un NotesProvider');
  }
  return context;
};